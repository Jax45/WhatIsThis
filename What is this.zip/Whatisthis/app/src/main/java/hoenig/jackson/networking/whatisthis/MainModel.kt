package hoenig.jackson.networking.whatisthis

class MainModel {
//    fun getResponse(str: String) : String {
//        if(str.toLowerCase() == "help"){
//            return "help"
//        }
//        else if(str.toLowerCase() == "settings" || str.toLowerCase() == "setting"){
//            return "settings"
//        }
//        else if(str.toLowerCase() == "repeat" || str.toLowerCase() == "repeat description"){
//            return "repeat"
//        }
//    }
}