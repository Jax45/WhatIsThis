package hoenig.jackson.networking.whatisthis

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Bitmap.CompressFormat
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GestureDetectorCompat
import kotlinx.android.synthetic.main.activity_main_debug.*
import kotlinx.android.synthetic.main.activity_main_talkback.*
import java.io.*
import java.net.InetAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


private const val DEBUG_TAG = "Gestures"

class MainActivity : AppCompatActivity(), GestureDetector.OnGestureListener,
    GestureDetector.OnDoubleTapListener {

    private var isAccessibilityEnabled: Boolean = true
    private var description: String = "This is a picture of something, I cannot tell you much more than that because I am not connected to a server."
    private lateinit var speechRecognizerIntent: Intent
    private lateinit var micButton: ImageView
    private var imageCapture: ImageCapture? = null
    private lateinit var outputDirectory: File
    private lateinit var cameraExecutor: ExecutorService

    private lateinit var mDetector: GestureDetectorCompat

    private lateinit var speechRecognizer: SpeechRecognizer
    val RecordAudioRequestCode = 1
    private lateinit var editText: EditText
    private var micON = false

    private lateinit var textToSpeech: TextToSpeech

    var prefs: SharedPreferences? = null


    private val serverIpAddress = "192.168.1.173"
    private val serverPort: Int = 5050
    private var imgbyte: ByteArray? = null
    private var connected = false
    private var imageTaken = false
    private val handler: Handler = Handler()
    var socket: Socket? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        isAccessibilityEnabled = am.isEnabled

        //connect to the server.
        if (serverIpAddress != "") {
            val cThread = Thread(ClientThread())
            cThread.start()
        }

        if(isAccessibilityEnabled == false) {
            setContentView(R.layout.activity_main_debug)
            editText = findViewById(R.id.editTextView);
            micButton = findViewById<ImageView>(R.id.microphoneIV)
        }
        else{
            setContentView(R.layout.activity_main_talkback)

            //set 4 buttons
            findViewById<Button>(R.id.talkbackRepeatBtn).setOnClickListener {
                speakDescription()
            }
            findViewById<Button>(R.id.talkbackSettingsBtn).setOnClickListener {
                val i = Intent(applicationContext, SettingsActivity::class.java)
                startActivity(i)
            }
            findViewById<Button>(R.id.talkbackTakePhotoBtn).setOnClickListener {
                takePhoto()
            }
            findViewById<Button>(R.id.talkbackVoiceCommandBtn).setOnClickListener {
                speechRecognizer.startListening(speechRecognizerIntent)
            }

        }
        prefs = getSharedPreferences("hoenig.jackson.networking.whatisthis", MODE_PRIVATE);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED){
            checkPermission()
        }


        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        textToSpeech = TextToSpeech(applicationContext) { status ->
            if (status != TextToSpeech.ERROR) {
                textToSpeech.setLanguage(Locale.US)
            }
        }

        speechRecognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(bundle: Bundle) {}
            override fun onBeginningOfSpeech() {
                if (!isAccessibilityEnabled) {
                    editText.setText("")
                    editText.setHint("Listening...")
                }
                Toast.makeText(baseContext, "Listening", Toast.LENGTH_SHORT).show()
            }

            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(bytes: ByteArray) {}
            override fun onEndOfSpeech() {}
            override fun onError(i: Int) {}
            override fun onResults(bundle: Bundle) {
                val data = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!isAccessibilityEnabled) {
                    micButton.setImageResource(android.R.drawable.ic_btn_speak_now)
                    editText.setText(data!![0])
                }
                if (!isAccessibilityEnabled) {
                    Toast.makeText(baseContext, data!![0], Toast.LENGTH_SHORT).show()
                }
                Log.d("Debug", data!![0])
                val str = data!![0]
                if (str.toLowerCase(Locale.ROOT) == "help") {
                    //explain tutorial again
                    speakTutorial()
                } else if (str.toLowerCase(Locale.ROOT) == "settings" || str.toLowerCase(Locale.ROOT) == "setting") {
                    //go to the settings screen
                    val i = Intent(applicationContext, SettingsActivity::class.java)
                    startActivity(i)
                } else if (str.toLowerCase(Locale.ROOT) == "repeat" || str.toLowerCase(Locale.ROOT) == "repeat description") {
                    //repeat description
                    speakDescription()
                } else {
                    textToSpeech.speak("I could not understand what command you wanted. For information on possible commands, say. help.", TextToSpeech.QUEUE_FLUSH, null)
                }

            }

            override fun onPartialResults(bundle: Bundle) {}
            override fun onEvent(i: Int, bundle: Bundle) {}
        })



        // hide the action bar
        supportActionBar?.hide()

        // Check camera permissions if all permission granted
        // start camera else ask for the permission
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS)
        }

        // Instantiate the gesture detector with the
        // application context and an implementation of
        // GestureDetector.OnGestureListener
        mDetector = GestureDetectorCompat(this, this)
        // Set the gesture detector as the double tap
        // listener.
        mDetector.setOnDoubleTapListener(this)
        if(!isAccessibilityEnabled) {
            // set on click listener for the button of capture photo
            // it calls a method which is implemented below
            findViewById<Button>(R.id.settingsButton).setOnClickListener {
                val i = Intent(applicationContext, SettingsActivity::class.java)
                startActivity(i)
            }
            findViewById<Button>(R.id.repeatButton).setOnClickListener {
                speakDescription()
            }
        }
        outputDirectory = getOutputDirectory()
        cameraExecutor = Executors.newSingleThreadExecutor()
        if (prefs!!.getBoolean("firstrun", true)) {
            // Do first run stuff here then set 'firstrun' as false
            speakTutorial()
            prefs!!.edit().putBoolean("firstrun", false).apply();
        }
    }

    private fun speakTutorial(){
        val toSpeak: String = "To use this app, double tap the screen to take a picture or " +
                "tap the screen once to speak a command.\n Possible commands are: " +
                "Repeat, which repeats the last description." +
                "Settings, which opens settings for editing." +
                "Help, which details this message again if you ever need it." +
                "Thank You"//model.getHelp();
        //Toast.makeText(applicationContext, toSpeak, Toast.LENGTH_SHORT).show()
        textToSpeech.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null)
    }
    private fun speakDescription(){
        textToSpeech.speak(description, TextToSpeech.QUEUE_FLUSH, null)
    }

    private fun takePhoto() {
        // Get a stable reference of the
        // modifiable image capture use case
        val imageCapture = imageCapture ?: return

        // Create time-stamped output file to hold the image
        val photoFile = File(
                outputDirectory,
                SimpleDateFormat(FILENAME_FORMAT, Locale.US).format(System.currentTimeMillis()) + ".jpg"
        )

        // Create output options object which contains file + metadata
        val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

        // Set up image capture listener,
        // which is triggered after photo has
        // been taken
        imageCapture.takePicture(
                outputOptions,
                ContextCompat.getMainExecutor(this),
                object : ImageCapture.OnImageSavedCallback {
                    override fun onError(exc: ImageCaptureException) {
                        Log.e(TAG, "Photo capture failed: ${exc.message}", exc)
                    }

                    override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                        val savedUri = Uri.fromFile(photoFile)

                        // set the saved uri to the image view
                        findViewById<ImageView>(R.id.iv_capture).visibility = View.VISIBLE
                        findViewById<ImageView>(R.id.iv_capture).setImageURI(savedUri)

                        var msg = "Photo capture succeeded: $savedUri"
                        if (isAccessibilityEnabled) {
                            msg = "Photo capture succeeded."
                        }
                        val filepath = savedUri.path
                        val imagefile = File(filepath)
                        var fis: FileInputStream? = null
                        try {
                            fis = FileInputStream(imagefile)
                        } catch (e: FileNotFoundException) {
                            // TODO Auto-generated catch block
                            e.printStackTrace()
                        }
                        //bitmap = BitmapFactory.decodeStream(fis);
                        val bm = BitmapFactory.decodeStream(fis)
                        imgbyte = getBytesFromBitmap(bm)

                        //send the image to the server
                        imageTaken = true;
                        if (serverIpAddress != "") {
                            val cThread = Thread(ClientThread())
                            cThread.start()
                        }

                        //Toast.makeText(baseContext, msg, Toast.LENGTH_LONG).show()
                        Log.d(TAG, msg)
                    }
                })
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener(Runnable {

            // Used to bind the lifecycle of cameras to the lifecycle owner
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            // Preview
            val preview = Preview.Builder()
                    .build()
                    .also {
                        if (isAccessibilityEnabled)
                            it.setSurfaceProvider(viewFinderTalkback.createSurfaceProvider())
                        else
                            it.setSurfaceProvider(viewFinderDebug.createSurfaceProvider())
                    }

            imageCapture = ImageCapture.Builder().build()

            // Select back camera as a default
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                // Unbind use cases before rebinding
                cameraProvider.unbindAll()

                // Bind use cases to camera
                cameraProvider.bindToLifecycle(
                        this, cameraSelector, preview, imageCapture
                )

            } catch (exc: Exception) {
                Log.e(TAG, "Use case binding failed", exc)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    // creates a folder inside internal storage
    private fun getOutputDirectory(): File {
        val mediaDir = externalMediaDirs.firstOrNull()?.let {
            File(it, resources.getString(R.string.app_name)).apply { mkdirs() }
        }
        return if (mediaDir != null && mediaDir.exists())
            mediaDir else filesDir
    }


    companion object {
        private const val TAG = "CameraXGFG"
        private const val FILENAME_FORMAT = "yyyy-MM-dd-HH-mm-ss-SSS"
        private const val REQUEST_CODE_PERMISSIONS = 20
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy();
        cameraExecutor.shutdown()
    }
    private fun checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), RecordAudioRequestCode)
        }
    }
    // checks the camera permission
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RecordAudioRequestCode && grantResults.size > 0) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
        }
        else if (requestCode == REQUEST_CODE_PERMISSIONS) {
            // If all permissions granted , then start Camera
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                // If permissions are not granted,
                // present a toast to notify the user that
                // the permissions were not granted.
                Toast.makeText(this, "Permissions not granted by the user.", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.getAction() == MotionEvent.ACTION_UP){
            //speechRecognizer.stopListening()
        }
        if (event.getAction() == MotionEvent.ACTION_DOWN){

        }
        return if (mDetector.onTouchEvent(event)) {
            true
        } else {
            super.onTouchEvent(event)
        }
    }

    override fun onDown(event: MotionEvent): Boolean {
        Log.d(DEBUG_TAG, "onDown: $event")
        return true
    }

    override fun onFling(
            event1: MotionEvent,
            event2: MotionEvent,
            velocityX: Float,
            velocityY: Float
    ): Boolean {
        Log.d(DEBUG_TAG, "onFling: $event1 $event2")
        return true
    }

    override fun onLongPress(event: MotionEvent) {
        Log.d(DEBUG_TAG, "onLongPress: $event")
    }

    override fun onScroll(
            event1: MotionEvent,
            event2: MotionEvent,
            distanceX: Float,
            distanceY: Float
    ): Boolean {
        Log.d(DEBUG_TAG, "onScroll: $event1 $event2")
        return true
    }

    override fun onShowPress(event: MotionEvent) {
        Log.d(DEBUG_TAG, "onShowPress: $event")
    }

    override fun onSingleTapUp(event: MotionEvent): Boolean {
        Log.d(DEBUG_TAG, "onSingleTapUp: $event")
        return true
    }

    override fun onDoubleTap(event: MotionEvent): Boolean {
        Log.d(DEBUG_TAG, "onDoubleTap: $event")
        takePhoto()
        return true
    }

    override fun onDoubleTapEvent(event: MotionEvent): Boolean {
        Log.d(DEBUG_TAG, "onDoubleTapEvent: $event")
        return true
    }

    override fun onSingleTapConfirmed(event: MotionEvent): Boolean {
        Log.d(DEBUG_TAG, "onSingleTapConfirmed: $event")
        textToSpeech.stop()
        micButton.setImageResource(android.R.drawable.presence_audio_online);
        speechRecognizer.startListening(speechRecognizerIntent);
        return true
    }
    override fun onPause() {
        textToSpeech.stop()
        //textToSpeech.shutdown()
        super.onPause()
    }
    inner class ClientThread : Runnable {
        override fun run() {
            try {
                val serverAddr: InetAddress = InetAddress.getByName(serverIpAddress)
                Log.d("ClientActivity", "C: Connecting...")
                socket = Socket(serverAddr, serverPort)
                val out = DataOutputStream(socket!!.getOutputStream())
                val output = socket!!.getOutputStream()
                connected = true

                    if(imageTaken) {
                        try {
                            imageTaken = false

                            Log.d("ClientActivity", "C: image writing.")


                            //send the filesize
                            val size = imgbyte!!.size //316427

                            out.writeInt(size)
                            out.flush()

                            output.write(imgbyte)
                            output.flush()

//


                            Log.d("ClientActivity", "C: Receiving response back ${size}")

                            //receive Response
                            //val inStream = DataInputStream(BufferedInputStream(socket!!.getInputStream()))
                            val inStream = BufferedReader(InputStreamReader(socket!!.getInputStream()))
                            val message = inStream.readLine()
                            //val str = inStream.readBytes()
                            Log.d("ClientActivity", "S:response: \"${message}\"")
                            description = message;
                            speakDescription()
                        } catch (e: java.lang.Exception) {
                            Log.e("ClientActivity", "S: Error", e)
                        }
                    }

                socket!!.close()
                Log.d("ClientActivity", "C: Closed.")
            } catch (e: java.lang.Exception) {
                Log.e("ClientActivity", "C: Error", e)
                connected = false
            }
        }
    }

    override fun onStop() {
        super.onStop()
        try {
            // MAKE SURE YOU CLOSE THE SOCKET UPON EXITING
            socket?.close()
            connected = false
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()
        //reconnect

    }

    fun getBytesFromBitmap(bitmap: Bitmap): ByteArray? {
        val stream = ByteArrayOutputStream()
        bitmap.compress(CompressFormat.JPEG, 70, stream)
        return stream.toByteArray()
    }


}

